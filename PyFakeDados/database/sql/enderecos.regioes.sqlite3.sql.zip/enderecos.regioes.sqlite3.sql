CREATE TABLE regioes (
    id INT PRIMARY KEY,
    sigla VARCHAR(2),
    nome VARCHAR(50)
);

INSERT INTO regioes (id, sigla, nome) VALUES
(1, 'N', 'Norte'),
(2, 'NE', 'Nordeste'),
(3, 'SE', 'Sudeste'),
(4, 'S', 'Sul'),
(5, 'CO', 'Centro-Oeste');